﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    public static GameController instance { get; private set; }

    [SerializeField] private UIManager uiManager;
    [SerializeField] private int scoreToWin = 2;
    [SerializeField] private int leftScore;
    [SerializeField] private int rightScore;

    [SerializeField] private bool inMenu;
    private Ball ball;

    private void Awake()
    {
        instance = this;
        ball = GameObject.FindGameObjectWithTag("Ball").GetComponent<Ball>();
    }
    public void Score(Paddle.Side side)
    {
        if (side == Paddle.Side.Left)
            leftScore++;
        else if (side == Paddle.Side.Right)
            rightScore++;
        uiManager.UpdateScoreText(leftScore, rightScore);
        if (IsGameOver())
        {
            if (inMenu)
            {
                ResetGame();
                leftScore = rightScore = 0;
            }
                
            else
                ball.gameObject.SetActive(false);
        }
        else
        {
            ResetGame();
        }

        
    }
    

    private bool IsGameOver()
    {
        bool result = false;
        if (leftScore >= scoreToWin)
            result = true;
        else if (rightScore >= scoreToWin)
            result = true;
        return result;
    }

    private void ResetGame()
    {
        ball.Reset();
        

    }

}
