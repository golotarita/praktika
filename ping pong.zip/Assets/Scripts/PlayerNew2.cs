﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerNew2 : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 5f;

    public bool isAi;
    private Ball ball;


    void Start()
    {
        ball = GameObject.FindGameObjectWithTag("Ball").GetComponent<Ball>();
    }

    // Update is called once per frame
    void Update()
    {

        float targetYPosition = GetNewYPosition();
        ClampPosition(ref targetYPosition);
        transform.position = new Vector3(transform.position.x, targetYPosition, transform.position.z);
    }

    private void ClampPosition(ref float yPosition)
    {
        float minY = Camera.main.ScreenToWorldPoint(new Vector3(0, 0)).y;
        float maxY = Camera.main.ScreenToWorldPoint(new Vector3(0, Screen.height)).y;

        yPosition = Mathf.Clamp(yPosition, minY, maxY);
    }

    private float GetNewYPosition()
    {
        if (isAi)
        {
            return Mathf.MoveTowards(transform.position.y, ball.transform.position.y, moveSpeed);
        }
        else
        {
            float movement = Input.GetAxisRaw("Vertical") * moveSpeed * Time.deltaTime;
            return transform.position.y + movement;
        }

    }

}
