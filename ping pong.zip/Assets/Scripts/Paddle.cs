﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Paddle : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 5f;

    public bool isAi;
    private Ball ball;
    private Vector2 forwardDirection;
    public enum Side { Left, Right }
    [SerializeField] private Side side;
    void Start()
    {
        ball = GameObject.FindGameObjectWithTag("Ball").GetComponent<Ball>();
        if (side == Side.Left)
            forwardDirection = Vector2.right;
        else if (side == Side.Right)
            forwardDirection = Vector2.left;
    }

    // Update is called once per frame
    void Update()
    {

        float targetYPosition = GetNewYPosition();
        ClampPosition(ref targetYPosition);
        transform.position = new Vector3(transform.position.x, targetYPosition, transform.position.z);
    }

    private void ClampPosition(ref float yPosition)
    {
        float minY = Camera.main.ScreenToWorldPoint(new Vector3(0, 0)).y;
        float maxY = Camera.main.ScreenToWorldPoint(new Vector3(0, Screen.height)).y;

        yPosition = Mathf.Clamp(yPosition, minY, maxY);
    }

    private float GetNewYPosition()
    {
        float result = transform.position.y;
        if (isAi)
        {
            return Mathf.MoveTowards(transform.position.y, ball.transform.position.y, moveSpeed * Time.deltaTime);
        }
        else
        {
            float movement = Input.GetAxisRaw("Vertical") * moveSpeed * Time.deltaTime;
            return transform.position.y + movement;
        }

    }

    //private bool BallIncoming() 
    //{ 
      //  float dotP = Vector2.Dot(ball.velocity, forwardDirection);
        //return dotP < 0f;
    //}
}


